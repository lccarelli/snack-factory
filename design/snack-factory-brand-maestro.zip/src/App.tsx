import React, { useState, useEffect, useRef } from "react";
import {
  Sparkles,
  Layers,
  Palette,
  Type,
  Grid,
  Copy,
  Check,
  Smartphone,
  Mail,
  FileText,
  MessageSquare,
  ChevronRight,
  Sun,
  Moon,
  Shield,
  Download,
  Flame,
  Volume2,
  Tv,
  CheckCircle2,
  XCircle,
  ExternalLink,
  Laptop
} from "lucide-react";
import BrandLogo from "./components/BrandLogo";
import IconGallery from "./components/IconGallery";
import PatternShowcase from "./components/PatternShowcase";
import { Message, BrandTab } from "./types";

export default function App() {
  const [theme, setTheme] = useState<"light" | "dark">("dark");
  const [activeTab, setActiveTab] = useState<BrandTab>("overview");
  const [copiedText, setCopiedText] = useState<string | null>(null);
  
  // Custom interactive state for typography playground
  const [typoPreviewText, setTypoPreviewText] = useState("Small bites, production-grade.");
  
  // Custom interactive state for business card mockup
  const [cardOwner, setCardOwner] = useState<"laura" | "nicolas">("laura");
  const [cardSide, setCardSide] = useState<"front" | "back">("front");

  // Custom interactive state for sticker generator
  const [stickerColor, setStickerColor] = useState<"accent" | "dark" | "light">("accent");

  // Chat/Brand Assistant state
  const [chatMessages, setChatMessages] = useState<Message[]>([
    {
      id: "1",
      role: "model",
      text: "¡Hola! I am the snack-factory Brand Maestro. I can draft Midjourney prompts for custom assets, brainstorm brand copy in our exact voice, or discuss our production-grade architecture. What are we shipping today?",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [inputMessage, setInputMessage] = useState("");
  const [isSending, setIsSending] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Sync theme class
    const root = document.documentElement;
    if (theme === "dark") {
      root.classList.add("dark");
    } else {
      root.classList.remove("dark");
    }
  }, [theme]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatMessages]);

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(label);
    setTimeout(() => setCopiedText(null), 2000);
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim() || isSending) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      role: "user",
      text: inputMessage,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setChatMessages((prev) => [...prev, userMsg]);
    setInputMessage("");
    setIsSending(true);

    try {
      const response = await fetch("/api/brand-assistant", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: userMsg.text,
          history: chatMessages.map((m) => ({ role: m.role, text: m.text })),
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to reach Brand Assistant server.");
      }

      const data = await response.json();
      setChatMessages((prev) => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          role: "model",
          text: data.text,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } catch (err: any) {
      setChatMessages((prev) => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          role: "model",
          text: `[Error]: Could not generate message. Please verify your GEMINI_API_KEY is configured correctly. Error: ${err.message}`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setIsSending(false);
    }
  };

  // Predefined prompts for easy one-click testing
  const promptSuggestions = [
    "Draft a Midjourney prompt for a sticker of a pixel sandwich",
    "Write a cold email to an international fintech startup",
    "Describe the snack-factory concept in Twin Peaks style",
    "Explain our technical stack as Nicolás"
  ];

  return (
    <div className="min-h-screen bg-brand-off-white dark:bg-brand-near-black text-brand-near-black dark:text-brand-off-white transition-colors duration-500 font-sans relative overflow-x-hidden flex flex-col justify-between" id="brand-maestro-app">
      
      {/* Decorative Brand Prompt Watermark Background */}
      <div className="absolute top-20 right-[-10%] opacity-[0.03] text-[12vw] font-bold font-mono tracking-tighter uppercase select-none pointer-events-none">
        snack-factory
      </div>
      <div className="absolute bottom-20 left-[-10%] opacity-[0.02] text-[10vw] font-serif italic tracking-tighter select-none pointer-events-none">
        bite_equals_byte
      </div>

      {/* Header Bar */}
      <header className="sticky top-0 z-50 bg-brand-off-white/80 dark:bg-brand-near-black/80 backdrop-blur-md border-b border-slate-200/80 dark:border-zinc-800/80 px-4 md:px-10 h-20 flex items-center justify-between" id="app-header">
        <div className="flex items-center space-x-2">
          <BrandLogo variant="horizontal" size="md" colorMode="dynamic" />
        </div>

        <div className="flex items-center space-x-4">
          {/* Quick theme feedback banner */}
          <span className="hidden md:inline font-mono text-[10px] uppercase tracking-wider text-neutral-400 dark:text-neutral-500">
            {theme === "dark" ? "CARAMEL COOKIE ❯ #E28743" : "SWEET CHOCO ❯ #8B5A2B"}
          </span>

          {/* Theme Switcher Button */}
          <button
            onClick={() => setTheme(theme === "light" ? "dark" : "light")}
            className="p-2.5 rounded-lg border border-slate-200 dark:border-zinc-800 bg-white dark:bg-stone-900/40 text-violet-600 dark:text-emerald-400 hover:scale-105 active:scale-95 transition-all duration-300 shadow-sm cursor-pointer"
            aria-label="Toggle brand theme mode"
            id="theme-toggle-btn"
          >
            {theme === "light" ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
          </button>
        </div>
      </header>

      {/* Main Container */}
      <div className="max-w-7xl w-full mx-auto px-4 md:px-8 py-8 flex-grow grid grid-cols-1 lg:grid-cols-12 gap-8" id="main-grid">
        
        {/* Navigation Sidebar */}
        <aside className="lg:col-span-3 flex flex-col space-y-2" id="sidebar-navigation">
          <p className="font-mono text-[10px] text-neutral-400 dark:text-neutral-500 uppercase tracking-widest px-3 mb-2">
            00. Identity Modules
          </p>
          
          <button
            onClick={() => setActiveTab("overview")}
            className={`w-full text-left px-4 py-3 rounded-xl font-mono text-xs flex items-center justify-between transition-all duration-200 cursor-pointer ${
              activeTab === "overview"
                ? "bg-violet-600/10 dark:bg-emerald-400/10 text-violet-700 dark:text-emerald-400 border-l-4 border-violet-600 dark:border-emerald-400 font-bold"
                : "text-slate-600 dark:text-neutral-400 hover:bg-slate-100 dark:hover:bg-zinc-900/50"
            }`}
          >
            <span>01. CORE BRAND STORY</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => setActiveTab("logo")}
            className={`w-full text-left px-4 py-3 rounded-xl font-mono text-xs flex items-center justify-between transition-all duration-200 cursor-pointer ${
              activeTab === "logo"
                ? "bg-violet-600/10 dark:bg-emerald-400/10 text-violet-700 dark:text-emerald-400 border-l-4 border-violet-600 dark:border-emerald-400 font-bold"
                : "text-slate-600 dark:text-neutral-400 hover:bg-slate-100 dark:hover:bg-zinc-900/50"
            }`}
          >
            <span>02. LOGO SUITE</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => setActiveTab("colors")}
            className={`w-full text-left px-4 py-3 rounded-xl font-mono text-xs flex items-center justify-between transition-all duration-200 cursor-pointer ${
              activeTab === "colors"
                ? "bg-violet-600/10 dark:bg-emerald-400/10 text-violet-700 dark:text-emerald-400 border-l-4 border-violet-600 dark:border-emerald-400 font-bold"
                : "text-slate-600 dark:text-neutral-400 hover:bg-slate-100 dark:hover:bg-zinc-900/50"
            }`}
          >
            <span>03. COLOR MATRIX</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => setActiveTab("typography")}
            className={`w-full text-left px-4 py-3 rounded-xl font-mono text-xs flex items-center justify-between transition-all duration-200 cursor-pointer ${
              activeTab === "typography"
                ? "bg-violet-600/10 dark:bg-emerald-400/10 text-violet-700 dark:text-emerald-400 border-l-4 border-violet-600 dark:border-emerald-400 font-bold"
                : "text-slate-600 dark:text-neutral-400 hover:bg-slate-100 dark:hover:bg-zinc-900/50"
            }`}
          >
            <span>04. TYPOGRAPHY SCALE</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => setActiveTab("iconography")}
            className={`w-full text-left px-4 py-3 rounded-xl font-mono text-xs flex items-center justify-between transition-all duration-200 cursor-pointer ${
              activeTab === "iconography"
                ? "bg-violet-600/10 dark:bg-emerald-400/10 text-violet-700 dark:text-emerald-400 border-l-4 border-violet-600 dark:border-emerald-400 font-bold"
                : "text-slate-600 dark:text-neutral-400 hover:bg-slate-100 dark:hover:bg-zinc-900/50"
            }`}
          >
            <span>05. ICONOGRAPHY</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => setActiveTab("patterns")}
            className={`w-full text-left px-4 py-3 rounded-xl font-mono text-xs flex items-center justify-between transition-all duration-200 cursor-pointer ${
              activeTab === "patterns"
                ? "bg-violet-600/10 dark:bg-emerald-400/10 text-violet-700 dark:text-emerald-400 border-l-4 border-violet-600 dark:border-emerald-400 font-bold"
                : "text-slate-600 dark:text-neutral-400 hover:bg-slate-100 dark:hover:bg-zinc-900/50"
            }`}
          >
            <span>06. PATTERNS & CRT</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => setActiveTab("applications")}
            className={`w-full text-left px-4 py-3 rounded-xl font-mono text-xs flex items-center justify-between transition-all duration-200 cursor-pointer ${
              activeTab === "applications"
                ? "bg-violet-600/10 dark:bg-emerald-400/10 text-violet-700 dark:text-emerald-400 border-l-4 border-violet-600 dark:border-emerald-400 font-bold"
                : "text-slate-600 dark:text-neutral-400 hover:bg-slate-100 dark:hover:bg-zinc-900/50"
            }`}
          >
            <span>07. BRAND APPLICATIONS</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => setActiveTab("voice")}
            className={`w-full text-left px-4 py-3 rounded-xl font-mono text-xs flex items-center justify-between transition-all duration-200 cursor-pointer ${
              activeTab === "voice"
                ? "bg-violet-600/10 dark:bg-emerald-400/10 text-violet-700 dark:text-emerald-400 border-l-4 border-violet-600 dark:border-emerald-400 font-bold"
                : "text-slate-600 dark:text-neutral-400 hover:bg-slate-100 dark:hover:bg-zinc-900/50"
            }`}
          >
            <span>08. VOICE & MANIFESTO</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>

          <div className="pt-4 border-t border-slate-200 dark:border-zinc-800/80 mt-4">
            <button
              onClick={() => setActiveTab("assistant")}
              className={`w-full text-left px-4 py-4 rounded-xl font-mono text-xs flex items-center justify-between transition-all duration-300 shadow-md border cursor-pointer ${
                activeTab === "assistant"
                  ? "bg-violet-600 text-white border-violet-700 dark:bg-emerald-400 dark:text-stone-950 dark:border-emerald-500 font-bold animate-pulse"
                  : "bg-white dark:bg-stone-900/50 text-violet-600 dark:text-emerald-400 border-slate-200 dark:border-zinc-800 hover:bg-violet-50 dark:hover:bg-emerald-400/5"
              }`}
            >
              <div className="flex items-center space-x-2">
                <Sparkles className="w-4 h-4" />
                <span>AI PROMPT MAESTRO</span>
              </div>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Quick Stats Panel */}
          <div className="p-4 bg-slate-100/50 dark:bg-stone-950/40 border border-slate-200/50 dark:border-zinc-800/50 rounded-xl mt-6 space-y-3">
            <h5 className="font-mono text-[9px] uppercase tracking-wider text-neutral-400 dark:text-neutral-500">
              STUDIO METRICS
            </h5>
            <div className="grid grid-cols-2 gap-2 font-mono text-[10px]">
              <div>
                <span className="text-neutral-400 block">HEADCOUNT</span>
                <span className="font-bold text-slate-800 dark:text-stone-100">2 SENIORS</span>
              </div>
              <div>
                <span className="text-neutral-400 block">AI RATION</span>
                <span className="font-bold text-slate-800 dark:text-stone-100">AUGMENTED</span>
              </div>
              <div>
                <span className="text-neutral-400 block">OUTPUT</span>
                <span className="font-bold text-slate-800 dark:text-stone-100">PROD-GRADE</span>
              </div>
              <div>
                <span className="text-neutral-400 block">SCALE</span>
                <span className="font-bold text-slate-800 dark:text-stone-100">UNLIMITED</span>
              </div>
            </div>
          </div>
        </aside>

        {/* Dynamic Workspace Container */}
        <main className="lg:col-span-9 bg-white dark:bg-stone-900 border border-slate-200 dark:border-zinc-800/80 rounded-2xl p-6 md:p-8 shadow-sm flex flex-col justify-between" id="guidelines-workspace">
          
          {/* Active Tab: OVERVIEW (Brand Story / Manifesto) */}
          {activeTab === "overview" && (
            <div className="space-y-8 animate-fadeIn" id="overview-tab">
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-zinc-800 pb-4">
                <div>
                  <span className="font-mono text-[10px] text-violet-600 dark:text-emerald-400 uppercase tracking-widest">
                    ❯ MODULE_01 // IDENTITY
                  </span>
                  <h2 className="text-2xl font-serif italic text-slate-900 dark:text-white mt-1">
                    The snack-factory Concept
                  </h2>
                </div>
                <Layers className="w-5 h-5 text-neutral-400" />
              </div>

              {/* Grid with split introduction */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-4">
                  <h3 className="font-mono text-xs font-bold text-neutral-400 uppercase tracking-wider">
                    THE PHILOSOPHY
                  </h3>
                  <p className="font-serif italic text-3xl leading-snug text-slate-800 dark:text-stone-200">
                    "Serious engineering, delivered like a great snack."
                  </p>
                  <p className="text-sm text-slate-600 dark:text-neutral-300 leading-relaxed">
                    We believe international software shouldn't require bloated corporate meetings, 
                    fluff-ridden invoices, or administrative bottlenecks. snack-factory builds pristine, 
                    production-grade code segments. They are small, extremely well-designed portions that 
                    satisfy exactly what your platform needs.
                  </p>
                  <div className="border-l-2 border-violet-600 dark:border-emerald-400 pl-4 py-1 italic text-xs text-neutral-400">
                    No-bullshit methodology, backed by relentless software architecture.
                  </div>
                </div>

                <div className="space-y-4 bg-slate-50 dark:bg-stone-950/40 p-6 rounded-xl border border-slate-200/60 dark:border-zinc-800/60">
                  <h3 className="font-mono text-xs font-bold text-violet-600 dark:text-emerald-400 uppercase tracking-wider">
                    THE ARCHITECTS
                  </h3>
                  <div className="space-y-4 font-mono text-xs">
                    <div className="pb-3 border-b border-slate-200/60 dark:border-zinc-800/40">
                      <strong className="text-slate-800 dark:text-stone-200">Laura Carelli</strong>
                      <span className="text-neutral-400 block mt-0.5">Staff Software Engineer & Tech Lead</span>
                      <p className="text-[11px] text-neutral-500 mt-1 font-sans">
                        Specializes in flawless backend system orchestration, mobile performance optimization, and automation loops.
                      </p>
                    </div>
                    <div>
                      <strong className="text-slate-800 dark:text-stone-200">Nicolás Sarfati</strong>
                      <span className="text-neutral-400 block mt-0.5">Software Architect & Performance Lead</span>
                      <p className="text-[11px] text-neutral-500 mt-1 font-sans">
                        Focuses on extreme system scalability, database performance auditing, and high-frequency data pipelines.
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Concept Visual Blueprint */}
              <div className="mt-8 border border-slate-200 dark:border-zinc-800 rounded-xl overflow-hidden">
                <div className="bg-slate-50 dark:bg-stone-950/60 p-4 border-b border-slate-200 dark:border-zinc-800 flex items-center justify-between">
                  <span className="font-mono text-[10px] text-slate-500 uppercase">CONCEPTUAL DUALITY MODEL</span>
                  <span className="font-mono text-[10px] text-neutral-400 px-2 py-0.5 bg-slate-200 dark:bg-stone-900 rounded">
                    bite = byte
                  </span>
                </div>
                <div className="p-8 grid grid-cols-1 md:grid-cols-2 gap-8 items-center bg-white dark:bg-stone-900">
                  <div className="space-y-4">
                    <div className="font-mono text-[11px] text-violet-600 dark:text-emerald-400">
                      ❯ CONCEPT_INDEX // 0x4B
                    </div>
                    <h4 className="text-lg font-bold">Food Meets Terminal Culture</h4>
                    <p className="text-xs text-slate-500 dark:text-neutral-400 leading-relaxed">
                      Every asset, copy element, or layout in the identity bridges technical terminal cues (pixel art, monospace metrics, chevron triggers) with highly appetizing snack analogies (cookies, chips, portions, dispensers).
                    </p>
                  </div>
                  <div className="flex justify-center">
                    <div className="relative group p-6 bg-slate-50 dark:bg-stone-950/40 rounded-xl border border-slate-200/50 dark:border-zinc-800/50 flex items-center justify-center w-full max-w-[280px] aspect-video">
                      <div className="absolute inset-0 opacity-10 scanlines rounded-xl"></div>
                      {/* Logo Mark preview */}
                      <BrandLogo variant="mark" size="lg" colorMode="dynamic" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Active Tab: LOGO SUITE */}
          {activeTab === "logo" && (
            <div className="space-y-8 animate-fadeIn" id="logo-tab">
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-zinc-800 pb-4">
                <div>
                  <span className="font-mono text-[10px] text-violet-600 dark:text-emerald-400 uppercase tracking-widest">
                    ❯ MODULE_02 // THE MARK
                  </span>
                  <h2 className="text-2xl font-serif italic text-slate-900 dark:text-white mt-1">
                    The Logo Suite
                  </h2>
                </div>
                <Grid className="w-5 h-5 text-neutral-400" />
              </div>

              {/* Core logo presentation */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                
                {/* Variant 1: Primary Horizontal */}
                <div className="p-6 bg-slate-50 dark:bg-stone-950/20 border border-slate-200 dark:border-zinc-800 rounded-xl space-y-4">
                  <span className="font-mono text-[10px] text-neutral-400 block uppercase">
                    A. PRIMARY HORIZONTAL LOCKUP (DEFAULT)
                  </span>
                  <div className="p-8 bg-white dark:bg-stone-900 border border-slate-100 dark:border-zinc-800/80 rounded-lg flex items-center justify-center min-h-[140px]">
                    <BrandLogo variant="horizontal" size="md" colorMode="dynamic" />
                  </div>
                  <p className="text-[11px] text-slate-500 leading-relaxed">
                    Optimized for headers, sidebars, and websites. Place with generous negative space of at least 1X height.
                  </p>
                </div>

                {/* Variant 2: Monogram Mark */}
                <div className="p-6 bg-slate-50 dark:bg-stone-950/20 border border-slate-200 dark:border-zinc-800 rounded-xl space-y-4">
                  <span className="font-mono text-[10px] text-neutral-400 block uppercase">
                    B. STANDALONE MONOGRAM (THE BYTE)
                  </span>
                  <div className="p-8 bg-white dark:bg-stone-900 border border-slate-100 dark:border-zinc-800/80 rounded-lg flex items-center justify-center min-h-[140px]">
                    <BrandLogo variant="mark" size="lg" colorMode="dynamic" />
                  </div>
                  <p className="text-[11px] text-slate-500 leading-relaxed">
                    A cookie with a pixel-stair bite removed from top-right and 3 chip blocks inside. Used for favicons and avatars.
                  </p>
                </div>
              </div>

              {/* Technical Blueprints & Restrictions */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-8">
                
                {/* Clear Space rules */}
                <div className="space-y-3">
                  <span className="font-mono text-[10px] text-violet-600 dark:text-emerald-400 block uppercase font-bold">
                    ❯ CLEAR SPACE SPECIFICATION
                  </span>
                  <BrandLogo variant="clearspace" />
                  <p className="text-xs text-neutral-400 mt-2">
                    The clear-space bounding box boundary represents a margin equal to 50% of the monogram mark's total width on all sides.
                  </p>
                </div>

                {/* Minimum sizes */}
                <div className="space-y-3">
                  <span className="font-mono text-[10px] text-violet-600 dark:text-emerald-400 block uppercase font-bold">
                    ❯ MINIMUM SCALE INDEX
                  </span>
                  <BrandLogo variant="minimum" />
                </div>
              </div>

              {/* Monochromatic Inverted Preview */}
              <div className="p-6 bg-slate-900 text-white rounded-xl space-y-4">
                <span className="font-mono text-[10px] text-neutral-400 block uppercase">
                  C. MONOCHROMATIC & INVERTED PRINT LOCKUP (HIGH CONTRAST)
                </span>
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-6 bg-stone-950 border border-zinc-800 rounded flex items-center justify-center">
                    <BrandLogo variant="horizontal" colorMode="darkOnly" size="sm" />
                  </div>
                  <div className="p-6 bg-stone-50 border border-slate-200 rounded flex items-center justify-center">
                    <BrandLogo variant="horizontal" colorMode="lightOnly" size="sm" />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Active Tab: COLORS */}
          {activeTab === "colors" && (
            <div className="space-y-8 animate-fadeIn" id="colors-tab">
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-zinc-800 pb-4">
                <div>
                  <span className="font-mono text-[10px] text-violet-600 dark:text-emerald-400 uppercase tracking-widest">
                    ❯ MODULE_03 // THE COOKIE MATRIX
                  </span>
                  <h2 className="text-2xl font-serif italic text-slate-900 dark:text-white mt-1">
                    The Cookie Color Palette
                  </h2>
                </div>
                <Palette className="w-5 h-5 text-neutral-400" />
              </div>

              {/* Rationale */}
              <p className="text-sm text-slate-600 dark:text-neutral-300 leading-relaxed">
                Nuestra paleta de colores juega con deliciosos marroncitos de cookies y chips de colores brillantes. En Dark Mode, usamos un color caramelo tostado y dorado sobre un fondo de cacao intenso. En Light Mode, una base de masa de vainilla mantecosa con acentos de chocolate delicioso. Los "chips" o confites de colores (rosa fresa, verde menta, cian arándano) añaden un toque alegre y único de sabor digital.
              </p>

              {/* Visual Grid representing dual-swatches */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                
                {/* Swatch 1: Dark mode */}
                <div className="border border-slate-200 dark:border-zinc-800 rounded-xl overflow-hidden shadow-sm bg-stone-950 text-white p-6 space-y-6">
                  <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
                    <span className="font-mono text-[11px] text-emerald-400 font-bold uppercase">
                      DARK ACTIVE MODE (TOASTED CARAMEL)
                    </span>
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  </div>

                  <div className="space-y-4">
                    {/* Primary Dark Background */}
                    <div className="flex items-center justify-between p-3 bg-[#170f0d] rounded border border-zinc-800">
                      <div>
                        <span className="font-mono text-xs font-bold block">DEEP_COCOA (BG)</span>
                        <span className="font-mono text-[10px] text-neutral-400">#170f0d</span>
                      </div>
                      <div className="w-8 h-8 rounded bg-[#170f0d] border border-zinc-700"></div>
                    </div>

                    {/* Caramel Accent */}
                    <div className="flex items-center justify-between p-3 bg-zinc-900 rounded border border-emerald-500/20">
                      <div>
                        <span className="font-mono text-xs font-bold block text-emerald-400">TOASTED_CARAMEL (ACCENT)</span>
                        <span className="font-mono text-[10px] text-neutral-400">#e28743</span>
                      </div>
                      <div className="w-8 h-8 rounded bg-[#e28743]"></div>
                    </div>

                    {/* Dark deep caramel accent */}
                    <div className="flex items-center justify-between p-3 bg-zinc-900 rounded border border-emerald-600/10">
                      <div>
                        <span className="font-mono text-xs font-bold block text-emerald-600">SWEET_AMBER</span>
                        <span className="font-mono text-[10px] text-neutral-400">#d97706</span>
                      </div>
                      <div className="w-8 h-8 rounded bg-[#d97706]"></div>
                    </div>
                  </div>
                </div>

                {/* Swatch 2: Light mode */}
                <div className="border border-slate-200 dark:border-zinc-800 rounded-xl overflow-hidden shadow-sm bg-[#faf6f0] text-[#1b120f] p-6 space-y-6">
                  <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                    <span className="font-mono text-[11px] text-violet-600 font-bold uppercase">
                      LIGHT ACTIVE MODE (COOKIE BROWN)
                    </span>
                    <span className="w-2.5 h-2.5 rounded-full bg-violet-600 animate-pulse"></span>
                  </div>

                  <div className="space-y-4">
                    {/* Primary Light Background */}
                    <div className="flex items-center justify-between p-3 bg-white rounded border border-violet-200">
                      <div>
                        <span className="font-mono text-xs font-bold block">VANILLA_DOUGH (BG)</span>
                        <span className="font-mono text-[10px] text-neutral-500">#faf6f0</span>
                      </div>
                      <div className="w-8 h-8 rounded bg-[#faf6f0] border border-violet-200"></div>
                    </div>

                    {/* Cookie Accent */}
                    <div className="flex items-center justify-between p-3 bg-white rounded border border-violet-400">
                      <div>
                        <span className="font-mono text-xs font-bold block text-violet-600">COOKIE_BROWN (ACCENT)</span>
                        <span className="font-mono text-[10px] text-neutral-500">#8b5a2b</span>
                      </div>
                      <div className="w-8 h-8 rounded bg-[#8b5a2b]"></div>
                    </div>

                    {/* Deep fudge chocolate */}
                    <div className="flex items-center justify-between p-3 bg-white rounded border border-violet-200">
                      <div>
                        <span className="font-mono text-xs font-bold block text-violet-800">CHOCO_FUDGE</span>
                        <span className="font-mono text-[10px] text-neutral-500">#54311c</span>
                      </div>
                      <div className="w-8 h-8 rounded bg-[#54311c]"></div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Candy Chips Showcase */}
              <div className="p-5 bg-[#faf6f0] dark:bg-[#170f0d] border border-slate-200/80 dark:border-zinc-800/80 rounded-xl">
                <h4 className="font-mono text-[11px] text-violet-600 dark:text-emerald-400 font-bold mb-3 uppercase">
                  ❯ CANDY CHIPS ACCENTS (SPRINKLES DE COLORES)
                </h4>
                <p className="text-xs text-slate-500 dark:text-neutral-400 mb-4">
                  These sweet, colorful sprinkles are pixel-perfect accents that break up empty space and represent custom code features or engineering accomplishments inside our software studio:
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="flex items-center space-x-3 p-3 bg-white dark:bg-stone-900 rounded-lg border border-slate-100 dark:border-zinc-800">
                    <span className="w-4 h-4 rounded bg-[#f43f5e] inline-block shrink-0"></span>
                    <div>
                      <span className="font-mono text-xs font-bold block">Strawberry Pink</span>
                      <span className="font-mono text-[9px] text-neutral-400">#f43f5e (Bite Accent)</span>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3 p-3 bg-white dark:bg-stone-900 rounded-lg border border-slate-100 dark:border-zinc-800">
                    <span className="w-4 h-4 rounded bg-[#10b981] inline-block shrink-0"></span>
                    <div>
                      <span className="font-mono text-xs font-bold block">Mint Green</span>
                      <span className="font-mono text-[9px] text-neutral-400">#10b981 (Performance)</span>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3 p-3 bg-white dark:bg-stone-900 rounded-lg border border-slate-100 dark:border-zinc-800">
                    <span className="w-4 h-4 rounded bg-[#06b6d4] inline-block shrink-0"></span>
                    <div>
                      <span className="font-mono text-xs font-bold block">Blueberry Cyan</span>
                      <span className="font-mono text-[9px] text-neutral-400">#06b6d4 (Architecture)</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Contrast Matrix / Do's & Don'ts */}
              <div className="p-5 bg-slate-50 dark:bg-stone-950/30 border border-slate-200/80 dark:border-zinc-800/80 rounded-xl">
                <h4 className="font-mono text-[11px] text-violet-600 dark:text-emerald-400 font-bold mb-4 uppercase">
                  ACCESSIBLE PAIRINGS & DO'S AND DON'TS
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                  <div className="space-y-3">
                    <span className="font-bold flex items-center text-green-600">
                      <CheckCircle2 className="w-4 h-4 mr-1.5" /> CORRECT USE CASES
                    </span>
                    <ul className="list-disc list-inside space-y-1 text-slate-500 dark:text-neutral-400">
                      <li>Use Caramel (#e28743) ONLY on dark cocoa backgrounds for legibility.</li>
                      <li>Use Cookie Brown (#8b5a2b) ONLY on vanilla backgrounds for brand consistency.</li>
                      <li>Use the candy sprinkles sparingly as accents in icons and micro-monograms.</li>
                    </ul>
                  </div>
                  <div className="space-y-3">
                    <span className="font-bold flex items-center text-red-500">
                      <XCircle className="w-4 h-4 mr-1.5" /> INCORRECT USE CASES
                    </span>
                    <ul className="list-disc list-inside space-y-1 text-slate-500 dark:text-neutral-400">
                      <li>Never place light gold text directly on a pure white background.</li>
                      <li>Do not overflow the layout with too many sprinkles, maintain the 60-30-10 rule.</li>
                      <li>Avoid mixing other bright primary gradients into technical text.</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Active Tab: TYPOGRAPHY */}
          {activeTab === "typography" && (
            <div className="space-y-8 animate-fadeIn" id="typography-tab">
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-zinc-800 pb-4">
                <div>
                  <span className="font-mono text-[10px] text-violet-600 dark:text-emerald-400 uppercase tracking-widest">
                    ❯ MODULE_04 // TYPE SCALE
                  </span>
                  <h2 className="text-2xl font-serif italic text-slate-900 dark:text-white mt-1">
                    The Typography System
                  </h2>
                </div>
                <Type className="w-5 h-5 text-neutral-400" />
              </div>

              {/* Editable Type Specimen Box */}
              <div className="bg-slate-50 dark:bg-stone-950/40 p-5 rounded-xl border border-slate-200 dark:border-zinc-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-[9px] uppercase tracking-wider text-neutral-400 dark:text-neutral-500">
                    INTERACTIVE TYPE SPECIMEN PLAYGROUND
                  </span>
                  <span className="font-mono text-[9px] text-slate-400 dark:text-neutral-400">
                    Type below to preview live changes
                  </span>
                </div>
                <input
                  type="text"
                  value={typoPreviewText}
                  onChange={(e) => setTypoPreviewText(e.target.value)}
                  className="w-full font-mono text-xs px-3 py-2 bg-white dark:bg-stone-900 border border-slate-200 dark:border-zinc-800 rounded-md focus:outline-none focus:ring-1 focus:ring-violet-500 dark:focus:ring-emerald-400"
                  placeholder="Type anything..."
                  id="typography-preview-input"
                />
              </div>

              {/* Family Breakdown */}
              <div className="space-y-8">
                
                {/* Display Font */}
                <div className="space-y-3 border-b border-slate-100 dark:border-zinc-800 pb-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-mono text-xs font-bold text-violet-600 dark:text-emerald-400 block">
                        A. DISPLAY SERIF (FRAUNCES)
                      </span>
                      <span className="text-[11px] text-neutral-400 font-mono">
                        Roles: Headlines, large title metrics, emotional hooks.
                      </span>
                    </div>
                    <span className="font-mono text-[10px] px-2 py-0.5 bg-slate-100 dark:bg-stone-950 rounded">
                      Fraunces Display
                    </span>
                  </div>
                  <div className="font-display italic text-4xl text-slate-800 dark:text-stone-100">
                    {typoPreviewText}
                  </div>
                  <div className="text-[11px] font-mono text-neutral-500">
                    Spec: Fraunces Display, Serif italic / Weight: 400-800 / Line height: 1.1x
                  </div>
                </div>

                {/* Sans Font */}
                <div className="space-y-3 border-b border-slate-100 dark:border-zinc-800 pb-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-mono text-xs font-bold text-violet-600 dark:text-emerald-400 block">
                        B. SANS BODY SANS (INTER)
                      </span>
                      <span className="text-[11px] text-neutral-400 font-mono">
                        Roles: General copy, user interfaces, inputs, paragraphs.
                      </span>
                    </div>
                    <span className="font-mono text-[10px] px-2 py-0.5 bg-slate-100 dark:bg-stone-950 rounded">
                      Inter Sans
                    </span>
                  </div>
                  <div className="font-sans text-lg text-slate-700 dark:text-stone-300">
                    {typoPreviewText}
                  </div>
                  <div className="text-[11px] font-mono text-neutral-500">
                    Spec: Inter Sans / Weight: 300-600 / Line height: 1.6x
                  </div>
                </div>

                {/* Mono Font */}
                <div className="space-y-3 pb-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-mono text-xs font-bold text-violet-600 dark:text-emerald-400 block">
                        C. METADATA MONOSPACE (JETBRAINS MONO)
                      </span>
                      <span className="text-[11px] text-neutral-400 font-mono">
                        Roles: Micro-labels, system outputs, data, terminal prompts, labels.
                      </span>
                    </div>
                    <span className="font-mono text-[10px] px-2 py-0.5 bg-slate-100 dark:bg-stone-950 rounded">
                      JetBrains Mono
                    </span>
                  </div>
                  <div className="font-mono text-sm text-slate-800 dark:text-stone-200">
                    ❯ {typoPreviewText.toLowerCase().replace(/\s+/g, '_')}
                  </div>
                  <div className="text-[11px] font-mono text-neutral-500">
                    Spec: JetBrains Mono / Weight: 400-600 / Line height: 1.5x
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Active Tab: ICONOGRAPHY */}
          {activeTab === "iconography" && (
            <div className="space-y-8 animate-fadeIn" id="iconography-tab">
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-zinc-800 pb-4">
                <div>
                  <span className="font-mono text-[10px] text-violet-600 dark:text-emerald-400 uppercase tracking-widest">
                    ❯ MODULE_05 // PIXEL SYSTEM
                  </span>
                  <h2 className="text-2xl font-serif italic text-slate-900 dark:text-white mt-1">
                    The Iconography System
                  </h2>
                </div>
                <Grid className="w-5 h-5 text-neutral-400" />
              </div>

              <p className="text-sm text-slate-600 dark:text-neutral-300 leading-relaxed">
                We avoid traditional, smooth corporate iconography. Every custom vector built for the snack-factory system incorporates structural, coarse, pixel-stair edges to resemble floating data-bites.
              </p>

              {/* Render dynamic icon grid gallery */}
              <IconGallery />
            </div>
          )}

          {/* Active Tab: PATTERNS */}
          {activeTab === "patterns" && (
            <div className="space-y-8 animate-fadeIn" id="patterns-tab">
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-zinc-800 pb-4">
                <div>
                  <span className="font-mono text-[10px] text-violet-600 dark:text-emerald-400 uppercase tracking-widest">
                    ❯ MODULE_06 // BACKSTORY PATTERNS
                  </span>
                  <h2 className="text-2xl font-serif italic text-slate-900 dark:text-white mt-1">
                    Patterns & Textures
                  </h2>
                </div>
                <Tv className="w-5 h-5 text-neutral-400" />
              </div>

              <p className="text-sm text-slate-600 dark:text-neutral-300 leading-relaxed">
                These patterns supply physical depth to client proposals, slides, and our marketing canvas. They draw inspiration from high-frequency scanlines and pixel grid structures.
              </p>

              {/* Render pattern cards */}
              <PatternShowcase />
            </div>
          )}

          {/* Active Tab: APPLICATIONS */}
          {activeTab === "applications" && (
            <div className="space-y-8 animate-fadeIn" id="applications-tab">
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-zinc-800 pb-4">
                <div>
                  <span className="font-mono text-[10px] text-violet-600 dark:text-emerald-400 uppercase tracking-widest">
                    ❯ MODULE_07 // COLLATERALS
                  </span>
                  <h2 className="text-2xl font-serif italic text-slate-900 dark:text-white mt-1">
                    Brand Applications
                  </h2>
                </div>
                <Laptop className="w-5 h-5 text-neutral-400" />
              </div>

              {/* Interactive Mockup 1: Business Card */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs font-bold text-violet-600 dark:text-emerald-400 uppercase">
                    A. INTERACTIVE DUAL-SIDE BUSINESS CARDS
                  </span>
                  <div className="flex items-center space-x-2 font-mono text-[10px]">
                    <button
                      onClick={() => setCardOwner("laura")}
                      className={`px-2 py-0.5 border cursor-pointer ${cardOwner === "laura" ? "bg-violet-600 dark:bg-emerald-400 text-white dark:text-black border-transparent" : "border-slate-300 dark:border-zinc-800"}`}
                    >
                      LAURA
                    </button>
                    <button
                      onClick={() => setCardOwner("nicolas")}
                      className={`px-2 py-0.5 border cursor-pointer ${cardOwner === "nicolas" ? "bg-violet-600 dark:bg-emerald-400 text-white dark:text-black border-transparent" : "border-slate-300 dark:border-zinc-800"}`}
                    >
                      NICOLÁS
                    </button>
                    <button
                      onClick={() => setCardSide(cardSide === "front" ? "back" : "front")}
                      className="px-2 py-0.5 bg-neutral-100 dark:bg-stone-950 hover:bg-neutral-200 dark:hover:bg-stone-900 border border-slate-300 dark:border-zinc-800 cursor-pointer"
                    >
                      FLIP CARD
                    </button>
                  </div>
                </div>

                {/* Card Container */}
                <div className="w-full max-w-[420px] aspect-[1.75/1] mx-auto relative rounded-xl shadow-lg border border-slate-200 dark:border-zinc-800 overflow-hidden transition-all duration-300" id="business-card-display">
                  {cardSide === "front" ? (
                    /* CARD FRONT */
                    <div className="absolute inset-0 bg-white dark:bg-stone-950 p-6 flex flex-col justify-between">
                      {/* Grid background motif */}
                      <div className="absolute inset-0 pixel-grid opacity-15" />
                      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-violet-600 to-indigo-500 dark:from-emerald-400 dark:to-teal-500" />
                      
                      <div className="relative z-10 flex justify-between items-start">
                        <BrandLogo variant="mark" size="sm" colorMode="dynamic" />
                        <span className="font-mono text-[8px] text-neutral-400 dark:text-neutral-500 uppercase tracking-widest">
                          STRICTLY_PRODUCTION_GRADE
                        </span>
                      </div>

                      <div className="relative z-10">
                        <h4 className="font-display font-bold text-xl text-slate-800 dark:text-stone-100 leading-none">
                          {cardOwner === "laura" ? "Laura Carelli" : "Nicolás Sarfati"}
                        </h4>
                        <p className="font-mono text-[9px] uppercase tracking-wider text-neutral-400 mt-1">
                          {cardOwner === "laura" ? "Staff Engineer & Tech Lead" : "Software Architect & Performance"}
                        </p>
                      </div>

                      <div className="relative z-10 flex justify-between items-end font-mono text-[8px] text-neutral-400 dark:text-neutral-500 border-t border-slate-100 dark:border-zinc-900/60 pt-2">
                        <span>{cardOwner === "laura" ? "carelli.lc@gmail.com" : "sarfati.n@gmail.com"}</span>
                        <span>snack-factory.com</span>
                      </div>
                    </div>
                  ) : (
                    /* CARD BACK */
                    <div className="absolute inset-0 bg-stone-950 text-white p-6 flex flex-col justify-between items-center text-center">
                      {/* Zigzag pattern */}
                      <div 
                        className="absolute inset-0 opacity-15"
                        style={{
                          backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='40' height='40' viewBox='0 0 40 40'%3E%3Cpath d='M0 20 L10 10 L20 20 L30 10 L40 20 L40 30 L30 20 L20 30 L10 20 L0 30 Z' fill='%2334d399' fill-rule='evenodd'/%3E%3C/svg%3E")`,
                          backgroundSize: "20px 20px"
                        }}
                      />
                      <div className="relative z-10 my-auto">
                        <h3 className="font-display font-bold italic text-3xl text-emerald-400 tracking-tight leading-none mb-1">
                          bite = byte.
                        </h3>
                        <p className="font-mono text-[9px] uppercase tracking-widest text-neutral-400">
                          small bites, production-grade
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Interactive Mockup 2: Proposal Header & Email Signature */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-8">
                
                {/* Email Signature */}
                <div className="space-y-3">
                  <span className="font-mono text-xs font-bold text-violet-600 dark:text-emerald-400 block uppercase">
                    B. PROPOSED EMAIL SIGNATURE
                  </span>
                  <div className="p-4 bg-slate-50 dark:bg-stone-950 border border-slate-200 dark:border-zinc-800 rounded-lg space-y-4">
                    <div className="font-mono text-xs text-slate-800 dark:text-stone-200">
                      <p className="font-bold">Laura Carelli</p>
                      <p className="text-[11px] text-neutral-400">Tech Lead | snack-factory</p>
                      <p className="text-[11px] text-violet-600 dark:text-emerald-400 mt-2">❯ small bites, production-grade.</p>
                      <p className="text-[10px] text-neutral-500 mt-1">w: snack-factory.com | c: +54 9 11 0000 0000</p>
                    </div>
                    <button
                      onClick={() => handleCopy("Laura Carelli\nTech Lead | snack-factory\n❯ small bites, production-grade.\n", "email-sig")}
                      className="w-full py-1.5 bg-white dark:bg-stone-900 border border-slate-300 dark:border-zinc-800 font-mono text-[10px] uppercase rounded text-center cursor-pointer hover:bg-slate-100"
                    >
                      {copiedText === "email-sig" ? "COPIED TO CLIPBOARD" : "COPY TEXT"}
                    </button>
                  </div>
                </div>

                {/* Sticker/T-Shirt Generator Mockup */}
                <div className="space-y-3">
                  <span className="font-mono text-xs font-bold text-violet-600 dark:text-emerald-400 block uppercase">
                    C. MERCHANDISE & STICKER
                  </span>
                  <div className="p-4 bg-slate-50 dark:bg-stone-950 border border-slate-200 dark:border-zinc-800 rounded-lg flex flex-col justify-between min-h-[160px]">
                    <div className="flex justify-center my-auto">
                      <div 
                        className={`w-28 h-28 rounded-full flex flex-col items-center justify-center border-4 border-dashed transition-all duration-300 ${
                          stickerColor === "accent" 
                            ? "bg-violet-600 dark:bg-emerald-400 text-white dark:text-black border-white/40" 
                            : stickerColor === "dark" 
                            ? "bg-black text-white border-zinc-800" 
                            : "bg-white text-black border-slate-300"
                        }`}
                      >
                        <BrandLogo variant="mark" size="sm" colorMode="mono" />
                        <span className="font-mono text-[8px] uppercase tracking-wider font-bold mt-2">
                          SNACK_PIXEL
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center justify-center space-x-2 mt-4 font-mono text-[9px]">
                      <span className="text-neutral-400">STICKER COLOR:</span>
                      <button onClick={() => setStickerColor("accent")} className="underline cursor-pointer">ACCENT</button>
                      <button onClick={() => setStickerColor("dark")} className="underline cursor-pointer">DARK</button>
                      <button onClick={() => setStickerColor("light")} className="underline cursor-pointer">LIGHT</button>
                    </div>
                  </div>
                </div>

              </div>
            </div>
          )}

          {/* Active Tab: VOICE & MESSAGING */}
          {activeTab === "voice" && (
            <div className="space-y-8 animate-fadeIn" id="voice-tab">
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-zinc-800 pb-4">
                <div>
                  <span className="font-mono text-[10px] text-violet-600 dark:text-emerald-400 uppercase tracking-widest">
                    ❯ MODULE_08 // EDITORIAL
                  </span>
                  <h2 className="text-2xl font-serif italic text-slate-900 dark:text-white mt-1">
                    Voice & Messaging
                  </h2>
                </div>
                <MessageSquare className="w-5 h-5 text-neutral-400" />
              </div>

              {/* Rationale and tone */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-4">
                  <h3 className="font-mono text-xs font-bold text-violet-600 dark:text-emerald-400 uppercase tracking-wider">
                    THE VOICE GUIDES
                  </h3>
                  <p className="text-sm text-slate-600 dark:text-neutral-300 leading-relaxed">
                    snack-factory speaks confidently without ever entering corporate puffery. We are technical professionals writing high-performance algorithms for world-class solutions.
                  </p>
                  
                  {/* manifesto card */}
                  <div className="p-5 bg-slate-50 dark:bg-stone-950 border border-slate-200 dark:border-zinc-800 rounded-xl space-y-3">
                    <span className="font-mono text-[9px] uppercase tracking-widest text-neutral-400">
                      STUDIO MANIFESTO
                    </span>
                    <p className="font-display italic text-base text-slate-800 dark:text-stone-200 leading-relaxed">
                      "We code in high-fidelity. We audit structures. We pack micro-components that deliver satisfying engineering solutions. No filler, no useless status updates, no administrative bloat. Small bites, production-grade."
                    </p>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="font-mono text-xs font-bold text-violet-600 dark:text-emerald-400 uppercase tracking-wider">
                    TONE EXAMPLES (DO'S AND DON'TS)
                  </h3>
                  <div className="space-y-4 text-xs font-mono">
                    <div className="p-3 bg-green-500/5 border border-green-500/10 rounded-lg">
                      <span className="text-green-500 font-bold block">❯ WE WRITE LIKE THIS:</span>
                      <p className="text-slate-600 dark:text-neutral-300 mt-1">
                        "Your database query patterns were bottlenecking checkout times by 42%. We rewrote the indexing strategy. It's compiled and ready in production."
                      </p>
                    </div>
                    <div className="p-3 bg-red-500/5 border border-red-500/10 rounded-lg">
                      <span className="text-red-500 font-bold block">❯ NOT LIKE THIS:</span>
                      <p className="text-slate-400 dark:text-neutral-400 mt-1 italic">
                        "Leveraging synergies and paradigm-shifting paradigms, our agile digital transformation orchestrators will maximize throughput..."
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Tagline variations */}
              <div className="pt-6 border-t border-slate-100 dark:border-zinc-800">
                <span className="font-mono text-xs font-bold text-neutral-400 uppercase block mb-4">
                  TAGLINE VARIATIONS FOR MARKETING MATRICES
                </span>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-[11px]">
                  <div className="p-4 bg-slate-50 dark:bg-stone-950 rounded border border-slate-200/50 dark:border-zinc-800/50">
                    <span className="text-neutral-400 block mb-1">01. PREFERRED TAGLINE</span>
                    <strong className="text-slate-800 dark:text-stone-100">"small bites, production-grade"</strong>
                  </div>
                  <div className="p-4 bg-slate-50 dark:bg-stone-950 rounded border border-slate-200/50 dark:border-zinc-800/50">
                    <span className="text-neutral-400 block mb-1">02. PERFORMANCE ALTERNATIVE</span>
                    <strong className="text-slate-800 dark:text-stone-100">"painless scalability, packaged neatly"</strong>
                  </div>
                  <div className="p-4 bg-slate-50 dark:bg-stone-950 rounded border border-slate-200/50 dark:border-zinc-800/50">
                    <span className="text-neutral-400 block mb-1">03. ARCHITECTURAL ALTERNATIVE</span>
                    <strong className="text-slate-800 dark:text-stone-100">"bite = byte"</strong>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Active Tab: AI PROMPT MAESTRO (ASSISTANT) */}
          {activeTab === "assistant" && (
            <div className="space-y-6 flex flex-col justify-between flex-grow animate-fadeIn" id="assistant-tab">
              <div className="border-b border-slate-100 dark:border-zinc-800 pb-4">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="font-mono text-[10px] text-violet-600 dark:text-emerald-400 uppercase tracking-widest font-bold flex items-center space-x-1">
                      <Sparkles className="w-3 h-3 mr-1" />
                      <span>❯ MODULE_09 // CONVERSATIONAL BRAND MAESTRO</span>
                    </span>
                    <h2 className="text-2xl font-serif italic text-slate-900 dark:text-white mt-1">
                      AI Prompt & Brand Architect
                    </h2>
                  </div>
                </div>
                <p className="text-xs text-neutral-400 mt-2">
                  Talk with the snack-factory Brand Identity engine to generate design parameters, Midjourney specs, copy pitches, and technical briefs.
                </p>
              </div>

              {/* Chat Output Area */}
              <div className="flex-grow min-h-[350px] max-h-[450px] overflow-y-auto border border-slate-200 dark:border-zinc-800 rounded-xl p-4 bg-slate-50/50 dark:bg-stone-950/40 space-y-4" id="chat-messages-box">
                {chatMessages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex flex-col max-w-[85%] ${
                      msg.role === "user" ? "ml-auto items-end" : "mr-auto items-start"
                    }`}
                  >
                    <div
                      className={`p-3.5 rounded-2xl text-xs leading-relaxed font-mono ${
                        msg.role === "user"
                          ? "bg-violet-600 text-white rounded-tr-none dark:bg-emerald-400 dark:text-stone-950"
                          : "bg-white dark:bg-stone-900 border border-slate-200 dark:border-zinc-800 text-slate-800 dark:text-stone-200 rounded-tl-none"
                      }`}
                    >
                      {/* Formatted Markdown-like paragraphs and code blocks */}
                      <div className="whitespace-pre-wrap select-text selection:bg-indigo-300">
                        {msg.text}
                      </div>
                    </div>
                    <span className="text-[9px] text-neutral-400 mt-1 px-1">
                      {msg.timestamp}
                    </span>
                  </div>
                ))}
                {isSending && (
                  <div className="flex items-center space-x-2 text-neutral-400 text-xs font-mono pl-2">
                    <span className="w-2 h-2 rounded-full bg-violet-600 dark:bg-emerald-400 animate-bounce"></span>
                    <span>Brand Maestro is thinking...</span>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>

              {/* Fast-suggest prompt capsules */}
              <div className="flex flex-wrap gap-2 py-1">
                {promptSuggestions.map((s, index) => (
                  <button
                    key={index}
                    onClick={() => setInputMessage(s)}
                    className="px-2.5 py-1 bg-white dark:bg-stone-900 border border-slate-200 dark:border-zinc-800 hover:border-violet-500 dark:hover:border-emerald-400 rounded-full font-mono text-[10px] text-slate-600 dark:text-neutral-400 transition-all cursor-pointer"
                  >
                    {s}
                  </button>
                ))}
              </div>

              {/* Chat Input Bar */}
              <form onSubmit={handleSendMessage} className="flex space-x-2" id="chat-input-form">
                <input
                  type="text"
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  placeholder="Ask for image prompts, code specifications, or website content..."
                  className="flex-grow px-4 py-3 bg-white dark:bg-stone-900 border border-slate-200 dark:border-zinc-800 rounded-xl font-mono text-xs focus:outline-none focus:ring-1 focus:ring-violet-500 dark:focus:ring-emerald-400"
                  id="chat-user-input"
                />
                <button
                  type="submit"
                  disabled={isSending || !inputMessage.trim()}
                  className="px-5 py-3 bg-violet-600 hover:bg-violet-700 dark:bg-emerald-400 dark:hover:bg-emerald-500 dark:text-stone-950 font-mono text-xs uppercase font-bold rounded-xl shadow transition-all duration-200 disabled:opacity-50 cursor-pointer"
                >
                  SEND
                </button>
              </form>
            </div>
          )}

        </main>
      </div>

      {/* Footer Bar */}
      <footer className="w-full h-16 bg-brand-near-black flex flex-col md:flex-row items-center justify-between px-4 md:px-10 text-[9px] font-mono uppercase tracking-[0.2em] text-white/40 border-t border-zinc-800 mt-12 py-4 md:py-0" id="app-footer">
        <div>© 2026 snack-factory (LAURA CARELLI + NICOLÁS SARFATI)</div>
        <div className="flex space-x-6 my-2 md:my-0">
          <span className="text-emerald-400">EMERALD.HEX: #34D399</span>
          <span className="text-violet-600 dark:text-violet-400">VIOLET.HEX: #7C3AED</span>
        </div>
        <div>BUILT FOR THE BOLD. PRODUCTION-GRADE.</div>
      </footer>
    </div>
  );
}
